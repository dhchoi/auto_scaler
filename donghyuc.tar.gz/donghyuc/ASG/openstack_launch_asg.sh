#!/bin/bash
# Our submitter will call this bash scripts to launch an ASG

# IMPORTANT:
#   This scripts reads parameters from ./configure using the source command
#   Reference: https://bash.cyberciti.biz/guide/Source_command
#   DO NOT CHANGE THE FOLLOWING LINE
source ~/devstack/configure

# IMPORTANT:
#   Shell scripts is not enough for implementing an ASG. What you need to do is
#   to write a Java/Python program and call it by this shell scripts. Make sure
#   all parameters specified in ./configure is passed to your program.

# IMPORTANT:
#   Run your program in background

#   Call your program here
java -DASG_IMAGE=$ASG_IMAGE -DASG_FLAVOR=$ASG_FLAVOR -DASG_NAME=$ASG_NAME \
-DLB_IPADDR=$LB_IPADDR -DCPU_UPPER_TRES=$CPU_UPPER_TRES -DCPU_LOWER_TRES=$CPU_LOWER_TRES \
-DMIN_INSTANCE=$MIN_INSTANCE -DMAX_INSTANCE=$MAX_INSTANCE \
-DEVAL_PERIOD=$EVAL_PERIOD -DEVAL_COUNT=$EVAL_COUNT \
-DCOOLDOWN=$COOLDOWN -DDELTA=$DELTA \
-jar ~/auto_scaler/target/cc-q-3-3.1.0-fat.jar > ~/auto_scaler/log &

echo $!
