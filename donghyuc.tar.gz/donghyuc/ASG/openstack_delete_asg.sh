#!/usr/bin/env bash

# This bash script should kill your ASG running in the background.

# Either command not working as was supposed to, based on project writeup
#kill $1
#kill $asgId

# Search process id manually
asgId=`ps -ef | grep "cc-q-3-3.1.0-fat.jar" | grep -v grep | awk '{print $2}'`
kill $asgId
